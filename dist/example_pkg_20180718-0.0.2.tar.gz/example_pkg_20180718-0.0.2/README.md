## How to use
pipenv install example_pkg_20180718
import example_pkg